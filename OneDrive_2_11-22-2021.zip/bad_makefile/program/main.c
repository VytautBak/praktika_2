#include <stdio.h>
#include <math_functions.h>

int main(void)
{
	printf("Add: %.2f\n", add(15, 18));
	printf("Subtract: %.2f\n", subtract(99, 54));
	printf("Divide: %.2f\n", divide(14785, 6));
	printf("Multi: %.2f\n", multi(15, 745));
	return 0;
}
