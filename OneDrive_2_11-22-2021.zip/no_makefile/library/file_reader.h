int get_first_line(char *filename, char **holder);
int dump_file(char *fileName);
