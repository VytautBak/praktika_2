#include <stdio.h>

void print_usage(void)
{
	printf("Available commands:\n");
	printf("+ is for add. Add takes two arguments\n");
	printf("- is for subtract. Subtract takes two arguments\n");
	printf("* is for multiply. Multiply takes two arguments\n");
	printf("/ is for divide. Divide takes two arguments\n");
	printf("q is for quit the program\n");
	printf("h is for help\n");
}
